# TEMPLATE PROJECT

**Project Title:**  <project title>  
**Project Team:** <team code and description>
**Tutor:** <tutor's name here> (<tutor's email here>)

## Project Description

`insert a project description here`

## Team Members

| Name | Discord Name | Bitbucket Username | Primary Email |
|--|--|--|--|
| Full Name Person 1 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |
| Full Name Person 2 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |
| Full Name Person 3 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |
| Full Name Person 4 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |
| Full Name Person 5 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |
| Full Name Person 6 | CPxx-First Last | @username | unik1234@uni.sydney.edu.au |

## Client Information

| Name | Email | Username | Phone |
|--|--|--|--|
| Full Name | client.email@domain.com | @username | +61 xxx xxx xxx |

## Table of Contents

`TODO: rebuild links to correctly link on bitbucket`

| Section | Last Updated |
|--|--|
| Project Outline Document | [Link - XX/XX/2024 ]() |
| Specification & Requirements Document | [Link - XX/XX/2024 ]() |
| Documentation for Client | [Link - XX/XX/2024 ]() |
| Meeting Minutes | [Link - XX/XX/2024 ]() |
| Weekly Update Videos | [Link - XX/XX/2024 ]() |
| Assessment - Other Mini Group Reports | [Link - XX/XX/2024 ]() |
| Assessment - Individual Reports | [Link - XX/XX/2024 ]() |
| Assessment - First Project Report (Group) | [Link - XX/XX/2024 ]() |
| Assessment - Final Project Report (Group) | [Link - XX/XX/2024 ]() |
| Assessment - Final Individual Reports | [Link - XX/XX/2024 ]() |


