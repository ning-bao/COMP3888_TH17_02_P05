# Documentation

All documentation to be delivered to the client at the conclusion of the course.  Please publish as a [ReadTheDocs](https://readthedocs.org/) website.

## Application

`put any documentation relating to the app here.  This is a template`

* [Getting Started]()
* [Usage Instructions]()

## Application & Solution

`put any documentation relating to your code here.  This is a template`

* [Explaination of Structure]()
* [Installation]()
* [Usage Instructions]()
* [Demons]()

## Other

`put anything else that you wish to submit as documentation here`
