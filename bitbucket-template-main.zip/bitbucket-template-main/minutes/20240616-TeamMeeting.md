# Meeting Minutes

**Date:** Friday 4 September 2020

**Time:** 6:00 PM

**Location:** Zoom Online Meeting

**Attendees:**

* Client Name (Client)
* Team Member 1 (Team Member)
* Team Member 2 (Team Member)
* Team Member 3 (Team Member)
* Team Member 4 (Team Member)
* Team Member 5 (Team Member)

**Applogies**

* Team Member 6 (Team Member) - __reason__

## Agenda

* Item 1 - Objective of meeting
* Item 2 - What was achieved
* Item 3 - (Action Items) Allocation of Tasks and outline of until next meeting

Meeting open at: XX:XX PM

## Item 1

`why was the meeting called?  Was it just a collaboration / pair programming session?`
`what work was planned to be done.`


## Item 2

`what got completed`


## Item 3

`did the project objectives change and what were they?`

| Name | Unikey | Video Link |
|--|--|--|
| Team Member 1 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 2 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 3 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 4 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 5 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 6 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |

## Item 4 - General Business

`any questions or comments not covered by the above sections`


Meeting closed at:  XX:XX PM
