# Meeting Minutes

**Date:** Friday 4 September 2020

**Time:** 6:00 PM

**Location:** Zoom Online Meeting

**Attendees:**

* Client Name (Client)
* Team Member 1 (Team Member)
* Team Member 2 (Team Member)
* Team Member 3 (Team Member)
* Team Member 4 (Team Member)
* Team Member 5 (Team Member)

**Applogies**

* Team Member 6 (Team Member) - __reason__

## Agenda

* Item 1 - Video Summaries & Feedback
* Item 2 - Challanges Discussion
* Item 3 - Technical & Requirement Questions
* Item 4 - Allocation of Tasks and outline of until next meeting
* Item 5 - General Business

Meeting open at: XX:XX PM

## Item 1

`include links to all YouTube videos in this section for each team member`
`remember to add these video links into a single playlist and to the other relevant pages in your report`

| Name | Unikey | Video Link |
|--|--|--|
| Team Member 1 | unik1234 | [YouTube]() |
| Team Member 2 | unik1234 | [YouTube]() |
| Team Member 3 | unik1234 | [YouTube]() |
| Team Member 4 | unik1234 | [YouTube]() |
| Team Member 5 | unik1234 | [YouTube]() |
| Team Member 6 | unik1234 | [YouTube]() |


## Item 2

`please list discussion items and questions here, with answers to questions`


## Item 3

`please list discussion items and questions here, with answers to questions`

## Item 4

`please update this table and list all challenges that will be achieved in next week`

| Name | Unikey | Video Link |
|--|--|--|
| Team Member 1 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 2 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 3 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 4 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 5 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |
| Team Member 6 | unik1234 | Short List Item 1, Short List Item 2, Short List Item 3, etc |

## Item 5 - General Business

`any questions or comments not covered by the above sections`


Meeting closed at:  XX:XX PM
