# Meetings

This page contains a list of all meetings conducted throughout the project.  

`suggestion:  name each of the minutes the date of the meeting and what type of meeting it was.  E.g. 2024-09-04 Client.md`

`TODO:  Add all the bitbucket links`

## Client Meetings

| Description | Date | Time Start | Time End | Minutes |
|--|--|--|--|--|
| Kick-Off Meeting | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Client Update (Start of Week) | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Client Update (End of Week) | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |


## Official Team Meetings

| Description | Date | Time Start | Time End | Minutes |
|--|--|--|--|--|
| Initial Team Meeting | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Organise Client Meeting | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Project Work | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |

## Additional Meetings

| Description | Date | Time Start | Time End | Minutes |
|--|--|--|--|--|
| Initial Team Meeting | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Organise Client Meeting | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Project Work | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |

## Tutorials

| Description | Date | Time Start | Time End | Minutes |
|--|--|--|--|--|
| Lecture Wk 1 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 2 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 3 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 4 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 5 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 6 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 7 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 8 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 9 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 10 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 11 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
| Tutorial Wk 12 | XX/XX/2024 | XX:XX PM | XX:XX PM | [Minutes]() |
